﻿$(function () {
    Defaults = {
        35: {
            page: {
                title: "店铺首页"
            },
            PModules: [{
                id: 9,
                type: 9,
                draggable: !0,
                sort: 0,
                content: {
                    showType: 2,
                    dataset: [{
                        link: "/Shop/index",
                        linkType: 6,
                        showtitle: "VERO",
                        title: "",
                        subtitle: "女装",
                        pic: "/PublicMob/images/mob/35banner01.jpg"
                    }]
                }
            },
            {
                id: 10,
                type: 9,
                draggable: !0,
                sort: 0,
                content: {
                    showType: 2,
                    dataset: [{
                        link: "/Shop/index",
                        linkType: 6,
                        showtitle: "VERO",
                        title: "",
                        subtitle: "女装",
                        pic: "/PublicMob/images/mob/35banner02.jpg"
                    }]
                }
            },
            {
                id: 11,
                type: 9,
                draggable: !0,
                sort: 0,
                content: {
                    showType: 2,
                    dataset: [{
                        link: "/Shop/index",
                        linkType: 6,
                        showtitle: "VERO",
                        title: "",
                        subtitle: "女装",
                        pic: "/PublicMob/images/mob/35banner03.jpg"
                    }]
                }
            },
            {
                id: 12,
                type: 9,
                draggable: !0,
                sort: 0,
                content: {
                    showType: 2,
                    dataset: [{
                        link: "/Shop/index",
                        linkType: 6,
                        showtitle: "VERO",
                        title: "",
                        subtitle: "女装",
                        pic: "/PublicMob/images/mob/35banner04.jpg"
                    }]
                }
            },
            {
                id: 13,
                type: 9,
                draggable: !0,
                sort: 0,
                content: {
                    showType: 2,
                    dataset: [{
                        link: "/Shop/index",
                        linkType: 6,
                        showtitle: "VERO",
                        title: "",
                        subtitle: "女装",
                        pic: "/PublicMob/images/mob/35banner05.jpg"
                    }]
                }
            }]
        }
    },
    HiShop.DIY.Unit.event_typeHeader_style35 = function (a, b) {
        b.dom_conitem,
        $("#tpl_diy_con_typeHeader_style35").html(),
        $("#tpl_diy_ctrl_typeHeader_style35").html()
    }
});